import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav>
      <div className="flex justify-between bg-black text-white ">
        <h1>React</h1>
        <ul className="flex space-x-4">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/hero">Hero</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
        <button className="bg-white-primary text-white">Submit</button>
      </div>
    </nav>
  );
}

export default Navbar;
