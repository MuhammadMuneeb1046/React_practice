

function Hero(){
    return (
        <>
            <h1>Hero Page</h1>
        </>
    )
}

export default Hero